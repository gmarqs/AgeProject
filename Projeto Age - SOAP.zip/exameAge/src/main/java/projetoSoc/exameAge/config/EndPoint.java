/**
 * Classe responsável por fazer a comunicação com o arquivo XSD.
 */

package projetoSoc.exameAge.config;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ws.server.endpoint.annotation.Endpoint;
import org.springframework.ws.server.endpoint.annotation.PayloadRoot;
import org.springframework.ws.server.endpoint.annotation.RequestPayload;
import org.springframework.ws.server.endpoint.annotation.ResponsePayload;

import br.com.gabrielmarques.ConsultaOneRequest;
import br.com.gabrielmarques.ConsultaOneResponse;
import br.com.gabrielmarques.ConsultaResponse;
import br.com.gabrielmarques.DeleteExameRequest;
import br.com.gabrielmarques.DeleteExameResponse;
import br.com.gabrielmarques.GetAllExamesRequest;
import br.com.gabrielmarques.GetAllExamesResponse;
import br.com.gabrielmarques.InsertNewExameRequest;
import br.com.gabrielmarques.InsertNewExameResponse;
import br.com.gabrielmarques.UpdateExameRequest;
import br.com.gabrielmarques.UpdateExameResponse;
import projetoSoc.exameAge.dao.ExameDAO;
import projetoSoc.exameAge.model.Exame;

@Endpoint
public class EndPoint {

	@Autowired
	public ExameDAO exameDAO;

	/**
	 * Método que recebe a requisição para cadastrar um exame.
	 * @param req
	 * @return InsertNewExameResponse
	 */
	@PayloadRoot(namespace = "http://gabrielmarques.com.br", localPart = "InsertNewExameRequest")
	@ResponsePayload
	public InsertNewExameResponse insertexame(@RequestPayload InsertNewExameRequest req) {
		InsertNewExameResponse res = new InsertNewExameResponse();
		if(exameDAO.insert(req) > 0) {
			res.setResponse("Inserido com sucesso");
			return res;
		}
		else {
			res.setResponse("Falha ao inserir");
			return res;
		}
			
		
	}

	/**
	 * Método que recebe a requisição para consultar um exame.
	 * @param req
	 * @return ConsultaOneResponse
	 */
	@PayloadRoot(namespace = "http://gabrielmarques.com.br", localPart = "ConsultaOneRequest")
	@ResponsePayload
	public ConsultaOneResponse consultaexame(@RequestPayload ConsultaOneRequest req) {

		Exame exame = exameDAO.consultabyId(req);
		if (exame == null) {
			throw new NullPointerException("Invalido Exame id " + req.getId());
		}
		ConsultaOneResponse res = new ConsultaOneResponse();
		res.setConsultaResponse(exameToConsultaResponse(exame));
		return res;
	}

	/**
	 * Método que recebe a requisição para deletar um exame.
	 * @param req
	 * @return DeleteExameResponse
	 */
	@PayloadRoot(namespace = "http://gabrielmarques.com.br", localPart = "DeleteExameRequest")
	@ResponsePayload
	public DeleteExameResponse deleteExame(@RequestPayload DeleteExameRequest req) {
		DeleteExameResponse res = new DeleteExameResponse();
		if (exameDAO.delete(req) > 0) {
			res.setResponse("Excluido com sucesso");
			return res;
		} else {
			res.setResponse("Falha ao excluir");
			return res;
		}
	}

	
	/**
	 * Método que recebe a requisição para atualizar um exame.
	 * @param req
	 * @return UpdateExameResponse
	 */
	@PayloadRoot(namespace = "http://gabrielmarques.com.br", localPart = "UpdateExameRequest")
	@Transactional
	@ResponsePayload
	public UpdateExameResponse atualizaExame(@RequestPayload UpdateExameRequest req) {
		UpdateExameResponse res = new UpdateExameResponse();
		exameDAO.update(req);
		if (exameDAO.update(req) > 0) {
			res.setResponse("Atualizado com sucesso");
			return res;
		} else {
			res.setResponse("Falha ao atualizar");
			return res;
		}
	}

	/**
	 * Método que recebe a requisição para consultar todos os exames.
	 * @param req
	 * @return GetAllExamesResponse
	 */
	@PayloadRoot(namespace = "http://gabrielmarques.com.br", localPart = "GetAllExamesRequest")
	@Transactional
	@ResponsePayload
	public GetAllExamesResponse consultaAll(@RequestPayload GetAllExamesRequest req) {
		GetAllExamesResponse res = new GetAllExamesResponse();
		List<Exame> listExame = exameDAO.consultaAll();
		exameToExamesResponse(listExame, res);
		return res;

	}

	private void exameToExamesResponse(List<Exame> listExame, GetAllExamesResponse res) {
		for (Exame exame : listExame) {
			res.getConsultaResponse().add(exameToConsultaResponse(exame));
		}

	}

	public ConsultaResponse exameToConsultaResponse(Exame exame) {
		ConsultaResponse res = new ConsultaResponse();
		res.setId(exame.getId());
		res.setNameMedico(exame.getNomeMedico());
		res.setNamePaciente(exame.getNomePaciente());
		res.setTelefonePaciente(exame.getTelefone());
		res.setLaudo(exame.getLaudo());
		res.setNomeExame(exame.getNomeExame());

		return res;

	}

}
