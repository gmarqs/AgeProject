/**
 * Classe DAO responsável por acessar e inserir informações no banco de dados utilizado JDBC.
 */

package projetoSoc.exameAge.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.support.DataAccessUtils;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import br.com.gabrielmarques.ConsultaOneRequest;
import br.com.gabrielmarques.DeleteExameRequest;
import br.com.gabrielmarques.InsertNewExameRequest;
import br.com.gabrielmarques.UpdateExameRequest; 
import projetoSoc.exameAge.model.Exame;

@Repository
public class ExameDAO {

	@Autowired
	private JdbcTemplate jdbctemplate;

	
	/**
	 * Realiza a inserção de um exame no banco de dados.
	 * @param req
	 * @return int
	 */
	public int insert(InsertNewExameRequest req) {
		String sql = "INSERT INTO EXAME (nomemedico, nomepaciente, telefone, laudo, nome_exame) values"
				+ " (?,?,?,?,?)";
		int i = jdbctemplate.update(sql, req.getNameMedico(), req.getNamePaciente(), req.getTelefonePaciente(),
				req.getLaudo(), req.getNomeExame());
		
		return i;
	}
	
	

	/**
	 * Realiza a consulta de um exame no banco de dados.
	 * @param req
	 * @return Exame
	 */
	public Exame consultabyId(ConsultaOneRequest req) {
		String sql = "SELECT * FROM EXAME WHERE ID = ?";
		try {
			List<Exame> query = jdbctemplate.query(sql, new BeanPropertyRowMapper<Exame>(Exame.class), req.getId());
			return DataAccessUtils.uniqueResult(query);
		} catch (Exception e) {
			Exame exame = null;
			return exame;
		}

	}

	
	/**
	 * Deleta um exame do banco de dados.
	 * @param req
	 * @return int
	 */
	public int delete(DeleteExameRequest req) {
		String sql = "DELETE FROM EXAME WHERE ID = ?";
		int i = jdbctemplate.update(sql, req.getId());
		return i;

	}

	/**
	 * Atualiza um exame no banco de dados.
	 * @param req
	 * @return int
	 */
	public int update(UpdateExameRequest req) {
		String sql = "UPDATE EXAME SET telefone = ?,  nome_exame = ?"
				+ " WHERE ID = ?";
		int i = jdbctemplate.update(sql, req.getTelefonePaciente(), req.getNomeExame(), req.getId());
		return i;
	}

	/**
	 * Consulta todos os exames do banco de dados.
	 * @return List<Exame>
	 */
	public List<Exame> consultaAll() {
		String sql = "SELECT * FROM EXAME";
		return jdbctemplate.query(sql, new BeanPropertyRowMapper<Exame>(Exame.class));
	}

}
