package projetoSoc.exameAge;

import java.util.Collections;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExameAgeApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExameAgeApplication.class, args);
	
		
	}

}
