/*
 * Classe modelo do projeto.
 */

package projetoSoc.exameAge.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Exame {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int Id;
	private String nomemedico;
	private String nomepaciente;
	private String telefone;
	private String laudo;
	private String nomeExame;
	;
	
	
	public String getNomeMedico() {
		return nomemedico;
	}
	public void setNomeMedico(String nomeMedico) {
		this.nomemedico = nomeMedico;
	}
	public String getNomePaciente() {
		return nomepaciente;
	}
	public void setNomePaciente(String nomePaciente) {
		this.nomepaciente = nomePaciente;
	}
	public String getTelefone() {
		return telefone;
	}
	public void setTelefone(String telefone) {
		this.telefone = telefone;
	}
	public String getNomeExame() {
		return nomeExame;
	}
	public void setNomeExame(String motivoConsulta) {
		this.nomeExame = motivoConsulta;
	}
	public int getId() {
		return Id;
	}
	public void setId(int id) {
		Id = id;
	}
	public String getLaudo() {
		return laudo;
	}
	public void setLaudo(String laudo) {
		this.laudo = laudo;
	}

}
