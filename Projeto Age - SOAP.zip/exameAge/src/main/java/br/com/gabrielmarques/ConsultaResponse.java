//
// Este arquivo foi gerado pela Arquitetura JavaTM para Implementação de Referência (JAXB) de Bind XML, v2.2.7 
// Consulte <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// Todas as modificações neste arquivo serão perdidas após a recompilação do esquema de origem. 
// Gerado em: 2020.09.23 às 10:21:55 PM BRT 
//


package br.com.gabrielmarques;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java de ConsultaResponse complex type.
 * 
 * <p>O seguinte fragmento do esquema especifica o conteúdo esperado contido dentro desta classe.
 * 
 * <pre>
 * &lt;complexType name="ConsultaResponse">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="id" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="nameMedico" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="namePaciente" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="telefonePaciente" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="laudo" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="nomeExame" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ConsultaResponse", propOrder = {
    "id",
    "nameMedico",
    "namePaciente",
    "telefonePaciente",
    "laudo",
    "nomeExame"
})
public class ConsultaResponse {

    protected int id;
    @XmlElement(required = true)
    protected String nameMedico;
    @XmlElement(required = true)
    protected String namePaciente;
    @XmlElement(required = true)
    protected String telefonePaciente;
    @XmlElement(required = true)
    protected String laudo;
    @XmlElement(required = true)
    protected String nomeExame;

    /**
     * Obtém o valor da propriedade id.
     * 
     */
    public int getId() {
        return id;
    }

    /**
     * Define o valor da propriedade id.
     * 
     */
    public void setId(int value) {
        this.id = value;
    }

    /**
     * Obtém o valor da propriedade nameMedico.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNameMedico() {
        return nameMedico;
    }

    /**
     * Define o valor da propriedade nameMedico.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNameMedico(String value) {
        this.nameMedico = value;
    }

    /**
     * Obtém o valor da propriedade namePaciente.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNamePaciente() {
        return namePaciente;
    }

    /**
     * Define o valor da propriedade namePaciente.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNamePaciente(String value) {
        this.namePaciente = value;
    }

    /**
     * Obtém o valor da propriedade telefonePaciente.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTelefonePaciente() {
        return telefonePaciente;
    }

    /**
     * Define o valor da propriedade telefonePaciente.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTelefonePaciente(String value) {
        this.telefonePaciente = value;
    }

    /**
     * Obtém o valor da propriedade laudo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLaudo() {
        return laudo;
    }

    /**
     * Define o valor da propriedade laudo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLaudo(String value) {
        this.laudo = value;
    }

    /**
     * Obtém o valor da propriedade nomeExame.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNomeExame() {
        return nomeExame;
    }

    /**
     * Define o valor da propriedade nomeExame.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNomeExame(String value) {
        this.nomeExame = value;
    }

}
