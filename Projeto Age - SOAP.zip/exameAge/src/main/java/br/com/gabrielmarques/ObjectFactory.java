//
// Este arquivo foi gerado pela Arquitetura JavaTM para Implementação de Referência (JAXB) de Bind XML, v2.2.7 
// Consulte <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// Todas as modificações neste arquivo serão perdidas após a recompilação do esquema de origem. 
// Gerado em: 2020.09.23 às 10:21:55 PM BRT 
//


package br.com.gabrielmarques;

import javax.xml.bind.annotation.XmlRegistry;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the br.com.gabrielmarques package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {


    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: br.com.gabrielmarques
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link ConsultaOneRequest }
     * 
     */
    public ConsultaOneRequest createConsultaOneRequest() {
        return new ConsultaOneRequest();
    }

    /**
     * Create an instance of {@link GetAllExamesRequest }
     * 
     */
    public GetAllExamesRequest createGetAllExamesRequest() {
        return new GetAllExamesRequest();
    }

    /**
     * Create an instance of {@link ConsultaOneResponse }
     * 
     */
    public ConsultaOneResponse createConsultaOneResponse() {
        return new ConsultaOneResponse();
    }

    /**
     * Create an instance of {@link ConsultaResponse }
     * 
     */
    public ConsultaResponse createConsultaResponse() {
        return new ConsultaResponse();
    }

    /**
     * Create an instance of {@link GetAllExamesResponse }
     * 
     */
    public GetAllExamesResponse createGetAllExamesResponse() {
        return new GetAllExamesResponse();
    }

    /**
     * Create an instance of {@link InsertNewExameResponse }
     * 
     */
    public InsertNewExameResponse createInsertNewExameResponse() {
        return new InsertNewExameResponse();
    }

    /**
     * Create an instance of {@link UpdateExameRequest }
     * 
     */
    public UpdateExameRequest createUpdateExameRequest() {
        return new UpdateExameRequest();
    }

    /**
     * Create an instance of {@link UpdateExameResponse }
     * 
     */
    public UpdateExameResponse createUpdateExameResponse() {
        return new UpdateExameResponse();
    }

    /**
     * Create an instance of {@link InsertNewExameRequest }
     * 
     */
    public InsertNewExameRequest createInsertNewExameRequest() {
        return new InsertNewExameRequest();
    }

    /**
     * Create an instance of {@link DeleteExameResponse }
     * 
     */
    public DeleteExameResponse createDeleteExameResponse() {
        return new DeleteExameResponse();
    }

    /**
     * Create an instance of {@link DeleteExameRequest }
     * 
     */
    public DeleteExameRequest createDeleteExameRequest() {
        return new DeleteExameRequest();
    }

}
