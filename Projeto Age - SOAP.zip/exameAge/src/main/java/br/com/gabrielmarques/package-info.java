//
// Este arquivo foi gerado pela Arquitetura JavaTM para Implementação de Referência (JAXB) de Bind XML, v2.2.7 
// Consulte <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// Todas as modificações neste arquivo serão perdidas após a recompilação do esquema de origem. 
// Gerado em: 2020.09.23 às 10:21:55 PM BRT 
//

@javax.xml.bind.annotation.XmlSchema(namespace = "http://gabrielmarques.com.br", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package br.com.gabrielmarques;
