@javax.xml.bind.annotation.XmlSchema(namespace = "http://gabrielmarques.com.br", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package br.com.gabrielmarques.cliente;
