package br.com.gabrielmarques.cliente.teste;

import br.com.gabrielmarques.cliente.ConsultaResponse;
import br.com.gabrielmarques.cliente.ExamePort;
import br.com.gabrielmarques.cliente.ExamePortService;
import br.com.gabrielmarques.cliente.GetAllExamesRequest;
import br.com.gabrielmarques.cliente.GetAllExamesResponse;
import br.com.gabrielmarques.cliente.UpdateExameRequest;
import br.com.gabrielmarques.cliente.UpdateExameResponse;

public class ClientTest {

	public static void main(String[] args) {
		ExamePortService service = new ExamePortService();
		ExamePort port = service.getExamePortSoap11();

		/**
		 * Inserir um exame.
		 * 
		 * InsertNewExameRequest insert = new InsertNewExameRequest();
		 * 
		 * insert.setNameMedico("Jos� Manuel"); insert.setNamePaciente("Gabriel
		 * Marques"); insert.setTelefonePaciente("12345678");
		 * insert.setLaudo("Trombose"); insert.setNomeExame("Ultrassonografia");
		 * 
		 * 
		 * InsertNewExameResponse res = port.insertNewExame(insert);
		 * 
		 * System.out.println(res.getResponse());
		 */

		/**
		 * Realizar uma consulta filtrando um exame.
		 * 
		 * ConsultaOneRequest consultaOne = new ConsultaOneRequest();
		 * 
		 * consultaOne.setId(2);
		 * 
		 * ConsultaOneResponse resconsulta = port.consultaOne(consultaOne);
		 * 
		 * System.out.println("Id: " + resconsulta.getConsultaResponse().getId());
		 * System.out.println("Nome do M�dico: " +
		 * resconsulta.getConsultaResponse().getNameMedico()); System.out.println("Nome
		 * do Paciente: " + resconsulta.getConsultaResponse().getNamePaciente());
		 * System.out.println("Telefone do Paciente: " +
		 * resconsulta.getConsultaResponse().getTelefonePaciente());
		 * System.out.println("Laudo: " + resconsulta.getConsultaResponse().getLaudo());
		 * System.out.println("Nome do exame: " +
		 * resconsulta.getConsultaResponse().getNomeExame());
		 * 
		 * 
		 */

		/**
		 * Deleta um exame.
		 */
		/*
		 * DeleteExameRequest deleteRequest = new DeleteExameRequest();
		 * 
		 * deleteRequest.setId(1);
		 * 
		 * DeleteExameResponse resDelete = port.deleteExame(deleteRequest);
		 * 
		 * System.out.println(resDelete.getResponse());
		 */
		
		
		/**
		 * Atualiza o Exame.
		 */
		/*
		 * UpdateExameRequest updateRequest = new UpdateExameRequest();
		 * 
		 * updateRequest.setId(10); updateRequest.setNomeExame("Exame de Sangue");
		 * updateRequest.setTelefonePaciente("12345678");
		 * 
		 * UpdateExameResponse res = port.updateExame(updateRequest);
		 * 
		 * System.out.println(res.getResponse());
		 */
		
		
		
		/**
		 * Lista todos os exames cadastrados.
		 */
		
		/*
		 * GetAllExamesRequest exameAll = new GetAllExamesRequest();
		 * 
		 * GetAllExamesResponse resAll = port.getAllExames(exameAll);
		 * 
		 * for (ConsultaResponse exame : resAll.getConsultaResponse()) {
		 * System.out.println("Id: " + exame.getId());
		 * System.out.println("Nome do M�dico: " + exame.getNameMedico());
		 * System.out.println("Nome " + "do Paciente: " + exame.getNamePaciente());
		 * System.out.println("Telefone do Paciente: " + exame.getTelefonePaciente());
		 * System.out.println("Laudo: " + exame.getLaudo());
		 * System.out.println("Nome do exame: " + exame.getNomeExame());
		 * System.out.println(); }
		 */
		

	}

}
