
package br.com.gabrielmarques.cliente;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java de anonymous complex type.
 * 
 * <p>O seguinte fragmento do esquema especifica o conte�do esperado contido dentro desta classe.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="ConsultaResponse" type="{http://gabrielmarques.com.br}ConsultaResponse"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "consultaResponse"
})
@XmlRootElement(name = "ConsultaOneResponse")
public class ConsultaOneResponse {

    @XmlElement(name = "ConsultaResponse", required = true)
    protected ConsultaResponse consultaResponse;

    /**
     * Obt�m o valor da propriedade consultaResponse.
     * 
     * @return
     *     possible object is
     *     {@link ConsultaResponse }
     *     
     */
    public ConsultaResponse getConsultaResponse() {
        return consultaResponse;
    }

    /**
     * Define o valor da propriedade consultaResponse.
     * 
     * @param value
     *     allowed object is
     *     {@link ConsultaResponse }
     *     
     */
    public void setConsultaResponse(ConsultaResponse value) {
        this.consultaResponse = value;
    }

}
